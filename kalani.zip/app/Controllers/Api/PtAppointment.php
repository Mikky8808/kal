<?php

namespace App\Controllers\Api;

use App\Models\MembersModel;
use App\Models\PtapptsModel;
use App\Models\TripsModel;

class PtAppointment extends BaseController
{
    protected $request1;
    
  
    public function getPTAppt()
    {

        $PtapptsModel = new PtapptsModel();
        $data = $PtapptsModel
            ->select('ptappts.id as id, PTStaff,reserveRide,
            ptappts.status as status, ptappts.memberId as memberId,
            DATE_FORMAT(apptDateTime,"%Y-%m-%d") as apptDate, ptappts.ptReason,
            reserveRide,apptDuration, apptTime, DATE_FORMAT(trips.pickupDate,"%H:%i") as ridePickupTime,
            DATE_FORMAT(rtntrip.pickupDate,"%H:%i") as rideDropTime, ptappts.wheelChair,
            CONCAT(members.firstName," ",members.LastName ) as MemberFullName,
            trips.instructions')
            ->where('ptappts.id', $this->data->ptapptsID)
            ->join('members', 'members.id = ptappts.memberId')
            ->join('trips', 'trips.ptapptsID = ptappts.id AND trips.rtnTrip = 0 and trips.deleted_at is null ', 'left')
            ->join('trips as rtntrip', 'rtntrip.ptapptsID = ptappts.id AND rtntrip.rtnTrip != 0 and rtntrip.deleted_at is null', 'left')

            ->get()
            ->getRow();

        return json_encode($data);
    }

    private function contUupdatePTApptRide($rtnTrip, $tripBase, $pick, $drop, $time)
    {
        $TripsModel = new TripsModel();

        $trip = $TripsModel->select('id')
            ->where('ptapptsID', $this->data->id)
            ->where('rtnTrip', $rtnTrip)
            ->first();

        if (!isset($trip)) {
            $trip = $tripBase;
        }
        $trip->wheelChair = $this->data->wheelChair;
        $trip->rtnTrip = $rtnTrip;
        $trip->pickAddress = $pick;
        $trip->dropAddress = $drop;
        $trip->instructions = $this->data->instructions;
        $trip->pickupDate = $this->data->apptDate . ' ' . $time;
        $trip->apptDate = $this->data->apptDate . ' ' . $this->data->apptTime;
        $TripsModel->save($trip);

    }
    private function updatePTApptRide()
    {
        $TripsModel = new TripsModel();
        if ($this->data->reserveRide !== 'Y') {
            $TripsModel->where('ptapptsID', $this->data->id)->delete();
            return;
        }
        $jsmAddress = '7872 Walker Street, La Palma, CA 90623';

        $MembersModel = new MembersModel();

        $tripBase = $MembersModel
            ->select('id as rider_id,
         CONCAT(firstName, " ",lastName) as name,
         CONCAT(address,", " ,city ,", ",state," ", zipCode) as pickAddress,
         phone'
            )
            ->where('id', $this->data->memberId)
            ->get()->getRow();

        $tripBase->ptapptsID = $this->data->id;
        $memberAddress = $tripBase->pickAddress;

        $this->contUupdatePTApptRide(0, $tripBase, $memberAddress, $jsmAddress, $this->data->ridePickupTime);
        $this->contUupdatePTApptRide(1, $tripBase, $jsmAddress, $memberAddress, $this->data->rideDropTime);

    }

    public function updatePTAppt()
    {
        $PtapptsModel = new PtapptsModel();
        $this->data->apptDateTime = $this->data->apptDate . ' ' . $this->data->apptTime;
        
        try {
            $this->db->transBegin();
            $Ptappts = $PtapptsModel->save($this->data);
            $this->updatePTApptRide();
        } catch (\Error $e) {
            $this->db->transRollback();
            throw new Exception("Error Processing Request", 1);

        }
        $this->db->transCommit();
        
        return ($this->data);

    }
    public function updatePTApptStatus()
    {
        $PtapptsModel = new PtapptsModel();

        return json_encode($PtapptsModel->save($this->data));

    }
    public function getAllPTAppt()
    {
        $PtapptsModel = new PtapptsModel();
        $data = $PtapptsModel
            ->select('ptappts.id as ptapptsID, ptappts.status,
        CONCAT(members.firstName," ",members.LastName ) as title,
        apptDateTime as start, users.ptColor as color, ptappts.wheelChair,
        DATE_ADD(apptDateTime, INTERVAL apptDuration MINUTE) as end,
        ptstatus.statusIcon, reserveRide')

            ->where('apptDateTime >=', $this->data->startStr)
            ->where('apptDateTime <=', $this->data->endStr)
            ->join('members', 'members.id = ptappts.memberId')
            ->join('users', 'users.username = ptappts.PTStaff')
            ->join('ptstatus', 'ptstatus.status = ptappts.status')

            // ->join('users', 'users.username = ptappts.PTStaff', 'left')

            // ->where ('apptDate <=',$this->data->end)
            ->findAll();

// $data['data']= $this.data;
        // return json_encode($PtapptsModel->findAll());

        echo json_encode($data);

    }

    public function createPTAppt()
    {
        $jsmAddress = '7872 Walker Street, La Palma, CA 90623';

        $PtapptsModel = new PtapptsModel();
        $MembersModel = new MembersModel();
        $TripsModel = new TripsModel();
        $trip = $MembersModel
            ->select('id as rider_id,
             CONCAT(firstName, " ",lastName) as name,
             CONCAT(address,", " ,city ,", ",state," ", zipCode) as pickAddress,
             phone'
            )
            ->where('id', $this->data->memberId)
            ->get()->getRow();

        $memberAddress = $trip->pickAddress;

        try {
            $this->db->transBegin();

            foreach ($this->data->daysSelected as $apptDate) {
                $this->data->apptDateTime = $apptDate . ' ' . $this->data->apptTime;

                $PtapptsModel->insert($this->data);

                if ($this->data->reserveRide == 'Y') {
                    $trip->wheelChair = $this->data->wheelChair;
                    $trip->instructions = $this->data->instructions;

                    $trip->rtnTrip = 0;
                    $trip->ptapptsID = $this->db->insertID();

                    $trip->pickAddress = $memberAddress;
                    $trip->dropAddress = $jsmAddress;
                    $trip->pickupDate = $apptDate . ' ' . $this->data->ridePickupTime;
                    $trip->apptDate = $this->data->apptDateTime;
                    $TripsModel->insert($trip);

                    $trip->pickupDate = $apptDate . ' ' . $this->data->rideDropTime;
                    $trip->pickAddress = $jsmAddress;
                    $trip->dropAddress = $memberAddress;
                    $trip->rtnTrip = 1;
                    $TripsModel->insert($trip);

                    $this->data->Tripinfo = $trip;

                }

            }
        } catch (\Error $e) {
            $this->db->transRollback();
            throw new Exception("Error Processing Request", 1);

        }
        $this->db->transCommit();

        echo json_encode($this->data);

    }

}
