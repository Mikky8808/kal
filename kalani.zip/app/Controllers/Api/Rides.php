<?php

namespace App\Controllers\Api;

use App\Models\TripsModel;

class Rides extends BaseController
{

    public function getTrip()
    {
        $TripsModel = new TripsModel();

        echo json_encode($TripsModel
                ->select('id, rider_id, driver, name, driver, phone, seStatus, wheelChair,
                DATE_FORMAT(pickupDate,"%Y-%m-%d") as pickupDate,
                DATE_FORMAT(pickupDate,"%H:%i") as pickupTime,
                DATE_FORMAT(apptDate,"%Y-%m-%d") as apptDate,
                DATE_FORMAT(apptDate,"%H:%i") as apptTime,
                passengers,pickAddress,dropAddress,instructions')
                ->where("id", $this->data->id)
                ->first());

    }
    public function updateRideAppt()
    {
        $TripsModel = new TripsModel();
       $trip =  $TripsModel->save($this->data);
       $this->data->trip = $trip;
        return json_encode($this->data);
    }

    public function getDayTrips()
    {
        $TripsModel = new TripsModel();

        echo json_encode($TripsModel
                ->select('id, driver, name, phone, seStatus,rtnTrip, wheelChair,
        DATE_FORMAT(pickupDate,"%h:%i %p") as pickupTime')
                ->where("DATE_FORMAT(pickupDate,'%Y-%m-%d')",
                    $this->data->date)->orderBy('pickupDate')->findAll());

    }

    public function assignDriver()
    {
        $TripsModel = new TripsModel();
        $TripsModel->save($this->data);
        return json_encode($this->data);
    }

    public function getAllRidesCal()
    {
        $TripsModel = new TripsModel();

        $data = $TripsModel
            ->select('trips.id as tripsId, seStatus,
        CONCAT(members.firstName," ",members.LastName ) as title,
        pickupDate as start,  wheelChair,
        DATE_ADD(pickupDate, INTERVAL 30 MINUTE) as end,
        CASE
           WHEN rtnTrip = 1 THEN "red"
           ELSE "green"
        END AS color,
        ridestatus.Icon', false)

            ->where('pickupDate >=', $this->data->startStr)
            ->where('pickupDate <=', $this->data->endStr)
            ->join('members', 'members.id = trips.rider_id')
            ->join('ridestatus', 'ridestatus.status = trips.seStatus')

            // ->join('users', 'users.username = ptappts.PTStaff', 'left')

            // ->where ('apptDate <=',$this->data->end)
            ->findAll();

// $data['data']= $this.data;
        // return json_encode($PtapptsModel->findAll());

        echo json_encode($data);

    }

    public function createRideAppt()
    {
        $TripsModel = new TripsModel();
        $trip = clone $this->data;
        try {
            $this->db->transBegin();
            foreach ($this->data->daysSelected as $apptDate) {

                $trip->apptDate = $apptDate . ' ' . $this->data->apptTime;
                $trip->pickupDate = $apptDate . ' ' . $this->data->ridePickupTime;
                $trip->rtnTrip = 0;
                $trip->pickAddress = $this->data->pickAddress;
                $trip->dropAddress = $this->data->dropAddress;
                $TripsModel->insert($trip);
                if ($this->data->roundTrip == 0) {
                    $trip->pickupDate = $apptDate . ' ' . $this->data->rideDropTime;
                    $trip->pickAddress = $this->data->dropAddress;
                    $trip->dropAddress = $this->data->pickAddress;
                    $trip->rtnTrip = 1;
                    $TripsModel->insert($trip);
                }

            }
        } catch (\Error$e) {
            $this->db->transRollback();
            throw new Exception($e);
        }

        $this->db->transCommit();

        return json_encode($this->data);

    }

}
