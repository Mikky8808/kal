<?php

namespace App\Controllers\Api;

use App\Models\MembersModel;
use App\Models\PtapptsModel;
use App\Models\TripsModel;

class Members extends BaseController
{

    public function saveMember()
    {
        $model = new MembersModel();

        if ($this->data->id > 0) {
            $model->save($this->data);
        } else {
            $this->data->id = $model->insert($this->data);
        }

        return json_encode($this->data);
    }
    public function getMember()
    {
        $model = new MembersModel();
        return json_encode($model->where('id', $this->data->id)->first());

    }
    
 
    public function getAllMembers()
    {
        $MembersModel = new MembersModel();

        return json_encode($MembersModel
                        ->select('id, phone,
                        CONCAT(firstName," ",LastName ) as fullName,
                        CONCAT(address,", ",city,", " ,state,zipCode ) as fullAddress')
                        ->findAll());

    }
    // public function getDayTrips()
    // {
    //     $model = new TripsModel();
    //     echo json_encode($model->where("DATE_FORMAT(pickupDate,'%Y-%m-%d')", $this->data->date)->orderBy('pickupDate')->findAll());
    //     // if ($id != 0) {
    //     //     echo json_encode($model->where('rider_id', $id)->findAll());
    //     // } else {
    //     //     echo json_encode($model->findAll());
    //     // }

    // }
//     public function updatePTApptStatus()
//     {
//         $PtapptsModel = new PtapptsModel();
        
//         return json_encode($PtapptsModel->save($this->data));


//     }
//     public function getAllPTAppt()
//     {
//         $PtapptsModel = new PtapptsModel();
//         $data = $PtapptsModel
//             ->select('ptappts.id as ptapptsID, ptappts.status,
//         CONCAT(members.firstName," ",members.LastName ) as title,
//         apptDateTime as start, users.ptColor as color,
//         DATE_ADD(apptDateTime, INTERVAL apptDuration MINUTE) as end,
//         ptstatus.statusIcon')

       
//             ->where('apptDateTime >=', $this->data->startStr)
//             ->where('apptDateTime <=', $this->data->endStr)
//             ->join('members', 'members.id = ptappts.memberId')
//             ->join('users','users.username = ptappts.PTStaff')
//             ->join('ptstatus','ptstatus.status = ptappts.status')

//             // ->join('users', 'users.username = ptappts.PTStaff', 'left')

//             // ->where ('apptDate <=',$this->data->end)
//             ->findAll();

// // $data['data']= $this.data;
//         // return json_encode($PtapptsModel->findAll());

//         echo json_encode($data);

//     }

//     public function createPTAppt()
//     {
//         $jsmAddress = ' 7872 Walker Street, La Palma, CA 90623';

//         $PtapptsModel = new PtapptsModel();
//         $MembersModel = new MembersModel();
//         $TripsModel = new TripsModel();
//         $trip = $MembersModel
//             ->select('id as rider_id,
//              CONCAT(firstName, " ",lastName) as name,
//              CONCAT(address,", " ,city ,", ",state," ", zipCode) as pickAddress,
//              phone,  '
//             )
//             ->where('id', $this->data->memberId)
//             ->get()->getRow();

//         $pickAddress = $trip->pickAddress;

//         $this->data->memberinfo = $trip;
//         try {
//             $this->db->transBegin();

//             foreach ($this->data->daysSelected as $apptDate) {
//                 $this->data->apptDateTime = $apptDate . ' ' . $this->data->apptTime;

//                 $PtapptsModel->insert($this->data);

//                 if ($this->data->reserveRide == 'Y') {
//                     $trip->rtnTrip = 0;
//                     $trip->pickAddress = $pickAddress;
//                     $trip->dropAddress = $jsmAddress;
//                     $trip->pickupDate =  $apptDate . ' ' . $this->data->ridePickupTime;
//                     $trip->apptDate = $this->data->apptDateTime;
//                     $TripsModel->insert($trip);
//                     $trip->pickupDate =  $apptDate . ' ' . $this->data->rideDropTime;
//                     $trip->pickAddress = $jsmAddress;
//                     $trip->dropAddress = $pickAddress;
//                     $trip->rtnTrip = 1;
//                     $TripsModel->insert($trip);

//                 }

//             }
//         } catch (\Error$e) {
//             $this->db->transRollback();
//             throw new Exception("Error Processing Request", 1);

//         }
//         $this->db->transCommit();

//         echo json_encode($this->data);
//         // if ($id != 0) {
//         //     echo json_encode($model->where('rider_id', $id)->findAll());
//         // } else {
//         //     echo json_encode($model->findAll());
//         // }

//     }

}
