<?php

namespace App\Controllers\Api;

use App\Models\XrayLogModel;

class Service extends BaseController
{

    public function saveXrayLog()
    {
        $model = new XrayLogModel();
        
        if ($this->data->id > 0) {
            $model->save($this->data);
        } else {
            $this->data->id = $model->insert($this->data);
        }
        $this->data->FCPATH = FCPATH;

        $this->data->files =  $this->request->getFiles();
        $this->data->images =$this->request->getFile('images');
        if ($imagefile = $this->request->getFiles()) {
            $logrec = $model->where('id', $this->data->id)->get()->getRow();
            $images = json_decode($logrec->images);
            foreach ($imagefile['images'] as $img) {
                 if ($img->isValid() && ! $img->hasMoved()) {
                    $images[] =  $img->getClientName();
                    $newName = $img->getClientName();
                    $img->move(FCPATH.'images/'  . $this->data->id , $newName,true);
                }

            }
            $images = array_unique($images);
            $logrec->images = json_encode($images);
  
            $model->save($logrec);

        }
        return json_encode($this->data);
    }
    public function getXrayLog()
    {
        $model = new XrayLogModel();
        return json_encode($model->where('id', $this->data->id)->get()->getRow());

    }
    public function getXrayLogs()
    {
        $model = new XrayLogModel();
        if (isset($this->data->provider) && $this->data->provider > '' ){
        return json_encode($model->orderBy('xrayDate', 'desc')
        ->where ('providerId',$this->data->provider )
        ->findAll()
            );
        }

        return json_encode($model->orderBy('xrayDate', 'desc')->findAll());
    }
}
