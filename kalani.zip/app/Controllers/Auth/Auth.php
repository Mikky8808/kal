<?php

namespace App\Controllers\Auth;

class Auth extends BaseController
{
    public function index()
    {
        $data["Authenticated"] = false;

        if ($this->session->username) {
            $data["Authenticated"] = true;
           $data['bootdata'] = $this->bootdata($this->session->username);

        }
        return json_encode($data);
    }

    public function login()
    {
        $data["Authenticated"] = false;
        $user = $this->db->table('users')->where('username', $this->data->username)->get()->getRow();
        if ($user) {
            if (($user->password) == sha1($this->data->password)) {
                $data["Authenticated"] = true;
                $this->session->set('username', $user->username);
                $data['bootdata'] = $this->bootdata($user->username);

            }
        }

        return json_encode($data);
    }

    private function bootdata($username)
    {
        $data['user'] =
        $this->db->table('users')->where('username', $username)->get()->getRow();
        $data['membertypes'] = $this->db->table('membertypes')->get()->getResult();
        $data['drivers'] = $this->db->table('users')->where('isDriver', true)->get()->getResult();
        $data['PTStaff'] = $this->db->table('users')->where('isPT', true)->get()->getResult();
        $data["RideStatus"] = $this->db->table("ridestatus")->get()->getResult();
        $data["ptStatus"] = $this->db->table("ptstatus")->get()->getResult();
        $data["ptReasons"] = $this->db->table("ptreasons")->get()->getResult();
        
        return $data;
    }
}
