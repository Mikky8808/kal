<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Home::index');
$routes->get('api/auth', '\App\Controllers\Auth\Auth::index');
$routes->post('api/auth/login', '\App\Controllers\Auth\Auth::login');
$routes->get('api/members/getAllMembers', '\App\Controllers\Api\Members::getAllMembers');
$routes->post('api/members/getMember', '\App\Controllers\Api\Members::getMember');
$routes->post('api/members/saveMember', '\App\Controllers\Api\Members::saveMember');

$routes->post('/api/rides/getDayTrips', '\App\Controllers\Api\Rides::getDayTrips');
$routes->post('/api/rides/assignDriver', '\App\Controllers\Api\Rides::assignDriver');
$routes->post('/api/rides/getAllRidesCal', '\App\Controllers\Api\Rides::getAllRidesCal');
$routes->post('/api/rides/createRideAppt', '\App\Controllers\Api\Rides::createRideAppt');
$routes->post('/api/rides/getTrip', '\App\Controllers\Api\Rides::getTrip');
$routes->post('/api/rides/updateRideAppt', '\App\Controllers\Api\Rides::updateRideAppt');



$routes->post('/api/Ptappts/getPTAppt', '\App\Controllers\Api\PtAppointment::getPTAppt');
$routes->post('/api/Ptappts/updatePTAppt', '\App\Controllers\Api\PtAppointment::updatePTAppt');
$routes->post('/api/Ptappts/createPTAppt', '\App\Controllers\Api\PtAppointment::createPTAppt');
$routes->post('/api/Ptappts/getAllPTAppt', '\App\Controllers\Api\PtAppointment::getAllPTAppt');
$routes->post('/api/Ptappts/updatePTApptStatus', '\App\Controllers\Api\PtAppointment::updatePTApptStatus');


$routes->get('api/logoff', static function () {
    $data = 'loggedoff';
    $session = \Config\Services::session();
    $session->destroy();
    header("HTTP/1.1 401 Unauthorized"); 
    exit;
    return json_encode($data);});

// $routes->get('/test/hello', 'Test::hello');
$routes->get('/(:any)', 'Home::index');



/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
